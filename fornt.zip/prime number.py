num = int(input("enter="))
if num <= 1:
    print(num, "is not a prime number.")
else:
    prime = True
    for i in range(2, num//2):
        if num % i == 0:
            prime = False
            break
    if prime:
        print(num, "prime number")
    else:
        print(num, "not a prime number")

