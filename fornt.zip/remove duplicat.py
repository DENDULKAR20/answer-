a=[1,2,3,1,4,2]
b={}
for i in range(len(a)):
    if a[i] not in b:
        b[a[i]]=1
    else:
        b[a[i]]+=1
for key in b.keys():
    print(key,end=" ")
    