a=input()
b=""
for i in a:
    b=i+b
print(b)