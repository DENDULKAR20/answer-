a=[1,2,3,4,5]
a1=[5,6,7,8,3]
b={}
for i in range(len(a)):
    if a[i] not in b:
        b[a[i]]=1
    else:
        b[a[i]]+=1
for i in range(len(a1)):
    if a1[i] not in b:
        b[a1[i]]=1
    else:
        b[a1[i]]+=1
for key in b.keys():
    if b[key]>=2:
        print(key,end=" ")
    