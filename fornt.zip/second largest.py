lis=[5,7,8,3,4]
max1=0
max2=0
for i in lis:
    if i>max1:
        max2=max1
        max1=i
    elif max1!=i and max2<i:
        max2=i
print(max2)