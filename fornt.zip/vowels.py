a=input('enter=')
count=0
vowels=['a','e','i','o','u','A','E','I','O','U']
for i in a:
    for j in vowels:
        if str(i)==str(j):
            count+=1
print("number of vowels present in string",count)