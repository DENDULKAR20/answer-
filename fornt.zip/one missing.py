def missing(a):
    if a[0]=="n":
        return a[1]-1
    elif a[len(a)-1]=="n":
        return a[len(a)-2]+1
    else:
        i=1
        b=1
        dup=0
        while b!=0:
            if a[dup]=="n":
                g=a[dup-1]+1
                return g
            else:
                dup+=1
            
a=[1,2,3,4,5,6,"n",8,9]
print(missing(a))