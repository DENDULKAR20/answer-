create database company_DB;
use company_DB;
create table company(id int,Name varchar(100),Mail_id varchar(100),salary int);
insert into company values(101,'ravi','ravi20@gmail.com',40000);
insert into company values(101,'john','john@gmail.com',40000);
update company set salary=55000 where name='john';