a=input("enter=")
num=0
len=len(a)
while len>num:
    for i in a:
        if i!=a[num]:
            print(i)
            len=0